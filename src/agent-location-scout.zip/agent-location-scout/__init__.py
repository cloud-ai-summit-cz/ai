"""Location Scout Agent - LangGraph-based agent for location analysis."""

__version__ = "0.1.0"
